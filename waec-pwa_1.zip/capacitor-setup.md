# Build the Android APK (Capacitor)
Needs: Node.js 18+, Android Studio (with an Android SDK), a computer.

1. Put the `site` folder next to package.json (it is the app, folder name `site` is used as webDir).
2. In this folder run:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
3. In Android Studio: Build > Build Bundle(s)/APK(s) > Build APK(s). The APK is in
   android/app/build/outputs/apk/debug/app-debug.apk  (share it by WhatsApp/Bluetooth; students tap to install).
4. For Play Store: Build > Generate Signed Bundle (AAB) and upload it at play.google.com/console.
After you change the app: copy the new site files, run `npx cap sync android`, rebuild.
